import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

/**
 * Decide quien puede entrar a un grupo de rutas (se usa en App.jsx):
 *   <GuardiaRuta requiereSesion />        -> solo con sesion; si no, va al login
 *   <GuardiaRuta requiereSesion={false} /> -> solo sin sesion (login/registro); si ya hay, va al catalogo
 */
export default function GuardiaRuta({ requiereSesion }) {
  const { usuario } = useAuth();

  if (requiereSesion) {
    return usuario ? <Outlet /> : <Navigate to="/login" replace />;
  }
  return usuario ? <Navigate to="/" replace /> : <Outlet />;
}
