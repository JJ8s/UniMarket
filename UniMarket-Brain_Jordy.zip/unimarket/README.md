# UniMarcket
Plataforma de comercio entre estudiantes para facilitar la compraventa de productos físicos en el campus (comida, ropa de segunda mano, tecnología y más). Optimiza la logística estudiantil coordinando entregas en zonas comunes y construyendo un entorno seguro mediante reputación comunitaria.

## Estructura del proyecto

```
dashboard/
├── index.html            # Página principal (catálogo de productos)
├── css/
│   ├── styles.css        # Estilos de index.html (header, tarjetas de producto, modal)
│   └── decoracion.css    # Estilos compartidos por login/registro y por el panel de perfil/pedidos
├── js/
│   ├── data.js           # "Base de datos" mock (localStorage): artículos, usuarios y sesión
│   └── script.js         # Lógica de index.html: filtros, búsqueda, modal, carrito, menú de perfil
├── img/                  # Imágenes (logo, ícono de carrito)
└── html/                 # Páginas secundarias
    ├── form.html          # Iniciar sesión
    ├── registro.html       # Crear cuenta
    ├── perfil-usuario.html # Panel de perfil del usuario
    ├── mis-pedidos.html    # Historial de pedidos (datos de ejemplo, aún no conectado a data.js)
    └── producto.html       # Placeholder para la vista de detalle de producto (pendiente de construir)
```

**Convención de nombres:** todos los archivos y carpetas van en minúsculas (kebab-case) para evitar problemas al subir el proyecto a un servidor con sistema de archivos sensible a mayúsculas/minúsculas (por ejemplo Linux).

Cuenta de prueba para iniciar sesión: `juan.perez@unimarket.edu` / `123456`.
