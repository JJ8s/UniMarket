//    - ARTICULOS_POR_DEFECTO : array semilla de artículos
//    - USUARIO_ACTUAL        : objeto con datos del usuario (mock)
//    - cargarArticulos()     : devuelve los artículos guardados
//    - guardarArticulos(arr) : persiste el array de artículos
//    - cargarCarrito()       : devuelve el carrito guardado
//    - guardarCarrito(arr)   : persiste el array del carrito
// ============================================================
 
// -------- LLAVES DE ALMACENAMIENTO (localStorage) --------
const CLAVE_ALMACENAMIENTO_ARTICULOS = 'unimarket_articulos';
const CLAVE_ALMACENAMIENTO_CARRITO = 'unimarket_carrito';
const CLAVE_ALMACENAMIENTO_SESION = 'unimarket_sesion';
const CLAVE_ALMACENAMIENTO_USUARIOS = 'unimarket_usuarios';
 
// -------- ARTÍCULOS SEMILLA --------
// Estructura de cada artículo:
//   id          : identificador único (number)
//   nombre      : nombre del producto (string)
//   descripcion : descripción corta del producto (string)
//   precio      : precio de venta en dólares (number)
//   calificacion: calificación del artículo/vendedor, de 0 a 5 (number)
//   categoria   : 'snacks' | 'ropa' | 'tecnologia' | 'otros'
//   universidad : universidad del vendedor (string)
//   vendedor    : nombre del vendedor (string)
//   distancia   : distancia en kilómetros hasta el usuario (number)
//   condicion   : estado del artículo, ej. 'Nuevo', 'Usado' (string)
//   creadoEn    : marca de tiempo de creación, en milisegundos (number)
const ARTICULOS_POR_DEFECTO = [
  {
    id: 1,
    nombre: 'Brownies de Chocolate Caseros',
    descripcion: 'Deliciosos brownies con chispas de chocolate, hechos en casa.',
    precio: 2.5,
    calificacion: 5.0,
    categoria: 'snacks',
    universidad: 'UNAM',
    vendedor: 'María G.',
    distancia: 0.5,
    condicion: 'Casero',
    creadoEn: Date.now() - 1000000,
  },
  {
    id: 2,
    nombre: 'Calculadora Científica Casio fx-991LA X',
    descripcion: 'Como nueva, con estuche para ingeniería.',
    precio: 15.0,
    calificacion: 4.8,
    categoria: 'tecnologia',
    universidad: 'IPN',
    vendedor: 'Carlos R.',
    distancia: 1.2,
    condicion: 'Usado',
    creadoEn: Date.now() - 2000000,
  },
  {
    id: 3,
    nombre: 'Chaqueta Denim Vintage',
    descripcion: 'Talla M, excelente estado, estilo retro.',
    precio: 20.0,
    calificacion: 4.9,
    categoria: 'ropa',
    universidad: 'Tec de Monterrey',
    vendedor: 'Ana V.',
    distancia: 2.5,
    condicion: '2da Mano',
    creadoEn: Date.now() - 3000000,
  },
  {
    id: 4,
    nombre: 'Bebida Energética Monster Original 473ml',
    descripcion: 'Lata fría, directo del kiosco central.',
    precio: 3.0,
    calificacion: 4.5,
    categoria: 'snacks',
    universidad: 'UAM',
    vendedor: 'Kiosco Central',
    distancia: 0.2,
    condicion: 'Nuevo',
    creadoEn: Date.now() - 4000000,
  },
];
 
// -------- USUARIO ACTUAL (datos de ejemplo) --------
// Cuando exista un sistema de inicio de sesión real, este objeto se
// debe reemplazar por los datos de la sesión activa del usuario.
//   nombre        : nombre completo del usuario (string)
//   nombreUsuario : nombre de usuario / handle (string)
//   correo        : correo electrónico asociado (string)
const USUARIO_ACTUAL = {
  nombre: 'Juan Pérez',
  nombreUsuario: '@juanperez',
  correo: 'juan.perez@unimarket.edu',
};

// -------- USUARIOS REGISTRADOS (mock, sin backend) --------
// Como el proyecto todavía no tiene servidor, la "base de datos" de
// usuarios es simplemente un array guardado en localStorage. Se
// arranca con una cuenta de prueba para poder loguearse de inmediato:
//   correo: juan.perez@unimarket.edu   contraseña: 123456
const USUARIOS_POR_DEFECTO = [
  {
    nombre: 'Juan Pérez',
    nombreUsuario: '@juanperez',
    correo: 'juan.perez@unimarket.edu',
    contrasena: '123456',
  },
];
 
/**
 * Lee los artículos guardados en localStorage.
 * Si no hay nada guardado (primera vez que se abre la app) o el
 * JSON está corrupto, devuelve una copia de los artículos semilla.
 * @returns {Array<Object>} lista de artículos
 */
function cargarArticulos() {
  const almacenados = localStorage.getItem(CLAVE_ALMACENAMIENTO_ARTICULOS);
  if (almacenados) {
    try {
      return JSON.parse(almacenados);
    } catch {
      return [...ARTICULOS_POR_DEFECTO];
    }
  }
  return [...ARTICULOS_POR_DEFECTO];
}
 
/**
 * Guarda el array de artículos completo en localStorage.
 * @param {Array<Object>} articulos - lista completa de artículos a guardar
 */
function guardarArticulos(articulos) {
  localStorage.setItem(CLAVE_ALMACENAMIENTO_ARTICULOS, JSON.stringify(articulos));
}
 
/**
 * Lee el carrito ("bolsa de compras") guardado en localStorage.
 * El carrito es un array simple con los IDs de los artículos agregados.
 * @returns {Array<number>} ids de artículos en la bolsa
 */
function cargarCarrito() {
  const almacenado = localStorage.getItem(CLAVE_ALMACENAMIENTO_CARRITO);
  if (almacenado) {
    try {
      return JSON.parse(almacenado);
    } catch {
      return [];
    }
  }
  return [];
}
 
/**
 * Guarda el carrito (array de ids de artículos) en localStorage.
 * @param {Array<number>} carrito
 */
function guardarCarrito(carrito) {
  localStorage.setItem(CLAVE_ALMACENAMIENTO_CARRITO, JSON.stringify(carrito));
}

// -------- USUARIOS (registro / login / logout, mock con localStorage) --------
/**
 * Lee la lista de usuarios registrados desde localStorage.
 * Si no hay nada guardado todavía, la crea con el usuario de prueba.
 * @returns {Array<Object>} lista de usuarios { nombre, nombreUsuario, correo, contrasena }
 */
function cargarUsuarios() {
  const almacenados = localStorage.getItem(CLAVE_ALMACENAMIENTO_USUARIOS);
  if (almacenados) {
    try {
      return JSON.parse(almacenados);
    } catch {
      return [...USUARIOS_POR_DEFECTO];
    }
  }
  return [...USUARIOS_POR_DEFECTO];
}

/**
 * Guarda la lista completa de usuarios en localStorage.
 * @param {Array<Object>} usuarios
 */
function guardarUsuarios(usuarios) {
  localStorage.setItem(CLAVE_ALMACENAMIENTO_USUARIOS, JSON.stringify(usuarios));
}

/**
 * Registra un nuevo usuario si el correo no está en uso.
 * @param {{nombre:string, nombreUsuario:string, correo:string, contrasena:string}} datos
 * @returns {{ok:boolean, mensaje?:string, usuario?:Object}}
 */
function registrarUsuario(datos) {
  const usuarios = cargarUsuarios();
  const correoNormalizado = (datos.correo || '').trim().toLowerCase();

  const yaExiste = usuarios.some(u => u.correo.trim().toLowerCase() === correoNormalizado);
  if (yaExiste) {
    return { ok: false, mensaje: 'Ya existe una cuenta con ese correo.' };
  }

  const nuevoUsuario = {
    nombre: datos.nombre || '',
    nombreUsuario: datos.nombreUsuario || '',
    correo: datos.correo,
    contrasena: datos.contrasena,
  };

  usuarios.push(nuevoUsuario);
  guardarUsuarios(usuarios);
  return { ok: true, usuario: nuevoUsuario };
}

/**
 * Verifica un correo y contraseña contra los usuarios registrados.
 * @param {string} correo
 * @param {string} contrasena
 * @returns {Object|null} el usuario si las credenciales son correctas, si no null
 */
function validarCredenciales(correo, contrasena) {
  const usuarios = cargarUsuarios();
  const correoNormalizado = (correo || '').trim().toLowerCase();

  return usuarios.find(u =>
    u.correo.trim().toLowerCase() === correoNormalizado && u.contrasena === contrasena
  ) || null;
}

/**
 * Guarda en localStorage al usuario que acaba de iniciar sesión.
 * @param {Object} usuario - usuario devuelto por validarCredenciales() o registrarUsuario()
 */
function iniciarSesion(usuario) {
  localStorage.setItem(CLAVE_ALMACENAMIENTO_SESION, JSON.stringify({
    nombre: usuario.nombre,
    nombreUsuario: usuario.nombreUsuario,
    correo: usuario.correo,
    iniciadaEn: Date.now(),
  }));
}

/**
 * Borra la sesión guardada. Se llama al hacer click en
 * "Salir de la sesión".
 */
function cerrarSesion() {
  localStorage.removeItem(CLAVE_ALMACENAMIENTO_SESION);
}

/**
 * Indica si hay una sesión activa guardada en localStorage.
 * @returns {boolean}
 */
function haySesionActiva() {
  return localStorage.getItem(CLAVE_ALMACENAMIENTO_SESION) !== null;
}

/**
 * Devuelve los datos del usuario con sesión activa, o null si no hay.
 * @returns {Object|null}
 */
function obtenerSesion() {
  const guardada = localStorage.getItem(CLAVE_ALMACENAMIENTO_SESION);
  if (!guardada) return null;
  try {
    return JSON.parse(guardada);
  } catch {
    return null;
  }
}
 
// -------- EXPOSICIÓN GLOBAL (para que script.js pueda usarlas) --------
window.ARTICULOS_POR_DEFECTO = ARTICULOS_POR_DEFECTO;
window.USUARIO_ACTUAL = USUARIO_ACTUAL;
window.cargarArticulos = cargarArticulos;
window.guardarArticulos = guardarArticulos;
window.cargarCarrito = cargarCarrito;
window.guardarCarrito = guardarCarrito;
window.cargarUsuarios = cargarUsuarios;
window.guardarUsuarios = guardarUsuarios;
window.registrarUsuario = registrarUsuario;
window.validarCredenciales = validarCredenciales;
window.iniciarSesion = iniciarSesion;
window.cerrarSesion = cerrarSesion;
window.haySesionActiva = haySesionActiva;
window.obtenerSesion = obtenerSesion;