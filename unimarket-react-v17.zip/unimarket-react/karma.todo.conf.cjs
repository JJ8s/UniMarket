const base = require('./karma.conf.cjs');

module.exports = function (config) {
  base(config);
  config.set({
    files: [
      { pattern: 'pruebas/**/*.spec.js', watched: false },
    ],
    preprocessors: {
      'pruebas/**/*.spec.js': ['esbuild'],
    },
  });
};
