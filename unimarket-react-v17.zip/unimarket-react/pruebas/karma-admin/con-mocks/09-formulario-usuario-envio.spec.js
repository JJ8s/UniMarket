import { cleanup, fireEvent, render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import FormularioUsuario from '../../../admin/components/FormularioUsuario';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Eventos', () => {
  afterEach(cleanup);

  it('K9) FormularioUsuario envia a onGuardar los datos escritos', async () => {
    const onGuardar = jasmine.createSpy('onGuardar').and.resolveTo({ ok: true });
    const { getByLabelText, getByText } = render(
      <MemoryRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <FormularioUsuario onGuardar={onGuardar} textoBoton="Crear usuario" />
      </MemoryRouter>
    );

    fireEvent.change(getByLabelText('Nombre completo *'), { target: { name: 'nombre', value: 'Ana Torres' } });
    fireEvent.change(getByLabelText('Correo *'), { target: { name: 'correo', value: 'ana@unimarket.edu' } });
    fireEvent.click(getByText('Crear usuario'));
    await Promise.resolve();

    expect(onGuardar).toHaveBeenCalledTimes(1);
    expect(onGuardar).toHaveBeenCalledWith(jasmine.objectContaining({ nombre: 'Ana Torres', correo: 'ana@unimarket.edu', rol: 'cliente' }));
  });
});
