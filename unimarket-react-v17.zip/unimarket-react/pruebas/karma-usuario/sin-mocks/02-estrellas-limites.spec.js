import { cleanup, render } from '@testing-library/react';
import Estrellas from '../../../src/usuario/components/Estrellas';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Propiedades (props)', () => {
  afterEach(cleanup);

  it('K2) Estrellas pluraliza las calificaciones y limita el promedio a 5', () => {
    const una = render(<Estrellas valor={3} cantidad={1} />);
    expect(una.getByText('(1 calificación)')).toBeTruthy();
    una.unmount();

    const varias = render(<Estrellas valor={9} cantidad={3} />);
    expect(varias.getByText('(3 calificaciones)')).toBeTruthy();
    expect(varias.getByText('5.0')).toBeTruthy();
    expect(varias.container.querySelector('.estrellas-relleno').style.width).toBe('100%');
  });
});
