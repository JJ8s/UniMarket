import { cleanup, render } from '@testing-library/react';
import TarjetaArticulo from '../../../src/usuario/components/TarjetaArticulo';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Renderizado correcto', () => {
  afterEach(cleanup);

  const ARTICULO = { id: 1, nombre: 'Calculadora Casio', precio: 12.5, categoria: 'tecnologia', vendedor: 'Carlos R.', condicion: 'Usado', distancia: 1.234, calificacion: 0, calificacionesCantidad: 0, fotos: [] };

  it('K4) TarjetaArticulo muestra nombre, precio con 2 decimales, distancia y "Sin calificar"', () => {
    const { getByText } = render(<TarjetaArticulo articulo={ARTICULO} onClick={() => {}} />);

    expect(getByText('Calculadora Casio')).toBeTruthy();
    expect(getByText('$12.50')).toBeTruthy();
    expect(getByText('1.2 km')).toBeTruthy();
    expect(getByText('Usado')).toBeTruthy();
    expect(document.body.textContent).toContain('Sin calificar');
  });
});
