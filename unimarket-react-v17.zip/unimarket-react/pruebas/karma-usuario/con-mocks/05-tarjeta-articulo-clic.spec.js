import { cleanup, fireEvent, render } from '@testing-library/react';
import TarjetaArticulo from '../../../src/usuario/components/TarjetaArticulo';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Eventos', () => {
  afterEach(cleanup);

  it('K5) TarjetaArticulo llama a onClick una vez al hacer clic', () => {
    const articulo = { id: 2, nombre: 'Brownies', precio: 2.5, categoria: 'snacks', vendedor: 'María G.', condicion: 'Casero', distancia: 0.5, calificacion: 5, calificacionesCantidad: 2, fotos: [] };
    const onClick = jasmine.createSpy('onClick');
    const { getByText } = render(<TarjetaArticulo articulo={articulo} onClick={onClick} />);
    expect(onClick).not.toHaveBeenCalled();

    fireEvent.click(getByText('Brownies'));

    expect(onClick).toHaveBeenCalledTimes(1);
  });
});
