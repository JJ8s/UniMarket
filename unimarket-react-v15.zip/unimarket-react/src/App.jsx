import { Navigate, Route, Routes } from 'react-router-dom';
import GuardiaRuta from './compartido/GuardiaRuta';
import Inicio from './usuario/pages/Inicio';
import QuienesSomos from './usuario/pages/QuienesSomos';
import Login from './usuario/pages/Login';
import Registro from './usuario/pages/Registro';
import Publicar from './usuario/pages/Publicar';
import PanelVendedor from './usuario/pages/PanelVendedor';
import Bolsa from './usuario/pages/Bolsa';
import Pago from './usuario/pages/Pago';
import Compras from './usuario/pages/Compras';
import Pedidos from './usuario/pages/Pedidos';
import Perfil from './usuario/pages/Perfil';
import rutasAdmin from './admin/rutasAdmin';
import { errorConfiguracion, supabaseConfigurado } from './data/supabase';

export default function App() {
  if (errorConfiguracion) {
    return (
      <main className="max-w-xl mx-auto p-8">
        <h1 className="text-2xl font-bold mb-3">Revisa la configuración de Supabase</h1>
        <p className="mb-2">{errorConfiguracion}</p>
        <p>Corrige el archivo <code>.env</code> y reinicia <code>npm run dev</code>.</p>
      </main>
    );
  }

  if (!supabaseConfigurado) {
    return (
      <main className="max-w-xl mx-auto p-8">
        <h1 className="text-2xl font-bold mb-3">Falta configurar Supabase</h1>
        <p className="mb-2">Crea un archivo <code>.env</code> en la raíz del proyecto con:</p>
        <pre className="bg-gray-100 p-3 rounded text-sm mb-2">{'VITE_SUPABASE_URL=https://TU-PROYECTO.supabase.co\nVITE_SUPABASE_ANON_KEY=tu-clave-publishable'}</pre>
        <p>Luego reinicia <code>npm run dev</code>. Los pasos completos están en el README.</p>
      </main>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Inicio />} />
      <Route path="/quienes-somos" element={<QuienesSomos />} />

      <Route element={<GuardiaRuta requiereSesion={false} />}>
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />
      </Route>

      <Route element={<GuardiaRuta requiereSesion />}>
        <Route path="/publicar" element={<Publicar />} />
        <Route path="/panel-vendedor" element={<PanelVendedor />} />
        <Route path="/bolsa" element={<Bolsa />} />
        <Route path="/pago" element={<Pago />} />
        <Route path="/pedidos" element={<Pedidos />} />
        <Route path="/compras" element={<Compras />} />
        <Route path="/perfil" element={<Perfil />} />
      </Route>

      {/* Panel de administracion */}
      <Route element={<GuardiaRuta requiereSesion rol="admin" />}>
        {rutasAdmin()}
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
