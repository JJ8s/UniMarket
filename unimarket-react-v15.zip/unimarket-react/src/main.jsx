import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { AuthProvider } from './context/AuthContext';
import { CarritoProvider } from './context/CarritoContext';
import { CategoriasProvider } from './context/CategoriasContext';

import './index.css';
import './usuario/styles/base.css';
import './usuario/styles/catalogo.css';
import './usuario/styles/publicar.css';
import './usuario/styles/panel-vendedor.css';
import './usuario/styles/auth.css';
import './usuario/styles/perfil.css';
import './usuario/styles/bolsa.css';
import './usuario/styles/pago.css';
import './usuario/styles/footer.css';
import './usuario/styles/quienes-somos.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <CategoriasProvider>
          <CarritoProvider>
            <App />
          </CarritoProvider>
        </CategoriasProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
