import { Link, useNavigate, useParams } from 'react-router-dom';
import { UMBRAL_STOCK_CRITICO, eliminarArticulo, obtenerArticulo } from '../../data/datos';
import { useCategorias } from '../../context/CategoriasContext';
import useConsulta from '../../hooks/useConsulta';
import { formatearFechaHora, formatearPrecio } from '../../utils/utilidades';
import EncabezadoPagina from '../components/EncabezadoPagina';
import InsigniaStock from '../components/InsigniaStock';
import Miniatura from '../components/Miniatura';

// Filas de la ficha
const dato = (etiqueta, valor) => (
  <div className="flex-grow-1" style={{ minWidth: "240px" }} key={etiqueta}>
    <div className="small text-secondary">{etiqueta}</div>
    <div>{valor || '-'}</div>
  </div>
);

/** "Mostrar producto" */
export default function ProductoDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { etiquetaCategoria } = useCategorias();
  const { datos: articulo, cargando } = useConsulta(() => obtenerArticulo(id), null, [id]);

  if (cargando) return <p className="text-secondary">Cargando...</p>;

  if (!articulo) {
    return (
      <>
        <EncabezadoPagina titulo="Producto no encontrado" />
        <Link to="/admin/productos" className="btn btn-outline-secondary">Volver a productos</Link>
      </>
    );
  }

  const borrar = async () => {
    if (!window.confirm(`¿Eliminar "${articulo.nombre}"? Esta acción no se puede deshacer.`)) return;
    const resultado = await eliminarArticulo(articulo.id);
    if (!resultado.ok) {
      window.alert(resultado.mensaje);
      return;
    }
    navigate('/admin/productos');
  };

  const critico = (articulo.stock ?? 0) <= UMBRAL_STOCK_CRITICO;

  return (
    <>
      <EncabezadoPagina titulo={articulo.nombre} subtitulo={`Producto #${articulo.id}`}>
        <Link to={`/admin/productos/${articulo.id}/editar`} className="btn btn-primary"><i className="fa-solid fa-pen"></i> Editar</Link>
        <button type="button" className="btn btn-outline-danger" onClick={borrar}><i className="fa-solid fa-trash"></i> Eliminar</button>
        <Link to="/admin/productos" className="btn btn-outline-secondary">Volver</Link>
      </EncabezadoPagina>

      {critico && (
        <div className="alert alert-warning py-2">
          Stock crítico: quedan {articulo.stock ?? 0} unidad(es).
        </div>
      )}

      <div className="card" style={{ maxWidth: 820 }}>
        <div className="card-body">
          <div className="d-flex gap-3 mb-3">
            <div style={{ width: 96, flexShrink: 0 }}>
              <div className="ratio ratio-1x1"><Miniatura articulo={articulo} /></div>
            </div>
            <div>
              <p className="mb-1">{articulo.descripcion || 'Sin descripción.'}</p>
              <InsigniaStock stock={articulo.stock} />
            </div>
          </div>
          <div className="d-flex flex-wrap gap-3">
            {dato('Categoría', etiquetaCategoria(articulo.categoria))}
            {dato('Precio', formatearPrecio(articulo.precio))}
            {dato('Stock', `${articulo.stock ?? 0} unidades`)}
            {dato('Estado', articulo.condicion)}
            {dato('Vendedor', articulo.vendedor)}
            {dato('Universidad', articulo.universidad)}
            {dato('SKU', articulo.sku)}
            {dato('Punto de entrega', articulo.entrega)}
            {dato('Calificación', (articulo.calificacion ?? 0).toFixed(1))}
            {dato('Publicado', formatearFechaHora(articulo.creadoEn))}
          </div>
        </div>
      </div>
    </>
  );
}
