import { Link, useParams } from 'react-router-dom';
import { ROL_ADMIN, articulosDeVendedor, obtenerUsuario, ordenesDeUsuario } from '../../data/datos';
import useConsulta from '../../hooks/useConsulta';
import { totalVentas } from '../../utils/reportes';
import { formatearPrecio } from '../../utils/utilidades';
import EncabezadoPagina from '../components/EncabezadoPagina';

export default function UsuarioDetalle() {
  const { correo } = useParams();
  const { datos: ficha, cargando } = useConsulta(async () => {
    const encontrado = await obtenerUsuario(correo);
    if (!encontrado) return { usuario: null, ordenes: [], publicaciones: 0 };
    const [ordenes, articulos] = await Promise.all([ordenesDeUsuario(encontrado.correo), articulosDeVendedor(encontrado.id)]);
    return { usuario: encontrado, ordenes, publicaciones: articulos.length };
  }, null, [correo]);

  if (cargando || !ficha) return <p className="text-secondary">Cargando...</p>;
  const { usuario, ordenes, publicaciones } = ficha;

  if (!usuario) {
    return (
      <>
        <EncabezadoPagina titulo="Usuario no encontrado" />
        <Link to="/admin/usuarios" className="btn btn-outline-secondary">Volver a usuarios</Link>
      </>
    );
  }

  const foto = usuario.foto;
  const enlace = encodeURIComponent(usuario.correo);

  return (
    <>
      <EncabezadoPagina titulo={usuario.nombre} subtitulo={usuario.nombreUsuario}>
        <Link to={`/admin/usuarios/${enlace}/editar`} className="btn btn-primary"><i className="fa-solid fa-pen"></i> Editar</Link>
        <Link to={`/admin/usuarios/${enlace}/historial`} className="btn btn-outline-primary"><i className="fa-solid fa-clock-rotate-left"></i> Historial de compras</Link>
        <Link to="/admin/usuarios" className="btn btn-outline-secondary">Volver</Link>
      </EncabezadoPagina>

      <div className="d-flex flex-wrap gap-3">
        <div className="flex-grow-1" style={{ minWidth: "320px" }}>
          <div className="card h-100">
            <div className="card-body">
              <div className="d-flex align-items-center gap-3 mb-3">
                {foto
                  ? <img src={foto} alt="Foto de perfil" className="rounded-circle" style={{ width: 64, height: 64, objectFit: 'cover' }} />
                  : <div className="rounded-circle bg-secondary-subtle d-flex align-items-center justify-content-center" style={{ width: 64, height: 64 }}><i className="fa-solid fa-user fs-4"></i></div>}
                <span className={`badge text-bg-${usuario.rol === ROL_ADMIN ? 'primary' : 'secondary'}`}>
                  {usuario.rol === ROL_ADMIN ? 'Administrador' : 'Cliente'}
                </span>
              </div>
              <div className="d-flex flex-wrap gap-3">
                <div className="flex-grow-1" style={{ minWidth: "240px" }}><div className="small text-secondary">Correo</div><div>{usuario.correo}</div></div>
                <div className="flex-grow-1" style={{ minWidth: "240px" }}><div className="small text-secondary">Usuario</div><div>{usuario.nombreUsuario || '-'}</div></div>
                <div className="flex-grow-1" style={{ minWidth: "100%" }}><div className="small text-secondary">Universidad</div><div>{usuario.universidad || '-'}</div></div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex-grow-1" style={{ minWidth: "260px" }}>
          <div className="d-flex flex-wrap gap-3">
            <div className="flex-grow-1" style={{ minWidth: "100px" }}><div className="card"><div className="card-body py-3"><div className="small text-secondary">Compras pagadas</div><div className="fs-4 fw-bold">{ordenes.filter((o) => o.estado === 'Pagada').length}</div></div></div></div>
            <div className="flex-grow-1" style={{ minWidth: "100px" }}><div className="card"><div className="card-body py-3"><div className="small text-secondary">Total gastado</div><div className="fs-4 fw-bold">{formatearPrecio(totalVentas(ordenes))}</div></div></div></div>
            <div className="flex-grow-1" style={{ minWidth: "100px" }}><div className="card"><div className="card-body py-3"><div className="small text-secondary">Publicaciones</div><div className="fs-4 fw-bold">{publicaciones}</div></div></div></div>
          </div>
        </div>
      </div>
    </>
  );
}
