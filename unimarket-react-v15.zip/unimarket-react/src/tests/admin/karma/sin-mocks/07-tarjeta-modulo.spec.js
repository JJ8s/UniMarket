import { cleanup, render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TarjetaModulo from '../../../../admin/components/TarjetaModulo';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Propiedades (props)', () => {
  afterEach(cleanup);

  it('K7) TarjetaModulo enlaza a la ruta recibida y muestra su icono y textos', () => {
    const { getByText, container } = render(
      <MemoryRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <TarjetaModulo a="/admin/productos" icono="fa-box" titulo="Productos" texto="Gestiona el inventario" />
      </MemoryRouter>
    );

    expect(container.querySelector('a').getAttribute('href')).toBe('/admin/productos');
    expect(container.querySelector('i').className).toContain('fa-box');
    expect(getByText('Productos')).toBeTruthy();
    expect(getByText('Gestiona el inventario')).toBeTruthy();
  });
});
