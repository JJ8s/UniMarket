import { cleanup, render } from '@testing-library/react';
import Miniatura from '../../../../admin/components/Miniatura';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Renderizado condicional', () => {
  afterEach(cleanup);

  it('K8) Miniatura usa la primera foto del producto o un color si no tiene fotos', () => {
    const conFoto = render(<Miniatura articulo={{ id: 1, fotos: ['data:image/jpeg;base64,AAAA'] }} />);
    expect(conFoto.container.firstChild.style.backgroundImage).toContain('data:image/jpeg;base64,AAAA');
    conFoto.unmount();

    const sinFoto = render(<Miniatura articulo={{ id: 1, fotos: [] }} />);
    expect(sinFoto.container.firstChild.getAttribute('style')).not.toContain('data:image');
    expect(sinFoto.container.firstChild.getAttribute('style')).toContain('background');
  });
});
