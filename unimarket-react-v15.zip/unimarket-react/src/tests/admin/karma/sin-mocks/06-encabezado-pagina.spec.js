import { cleanup, render } from '@testing-library/react';
import EncabezadoPagina from '../../../../admin/components/EncabezadoPagina';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Renderizado condicional', () => {
  afterEach(cleanup);

  it('K6) EncabezadoPagina muestra subtitulo y botones solo cuando se entregan', () => {
    const simple = render(<EncabezadoPagina titulo="Usuarios" />);
    expect(simple.getByText('Usuarios')).toBeTruthy();
    expect(simple.container.querySelector('p')).toBeNull();
    expect(simple.container.querySelector('.d-print-none')).toBeNull();
    simple.unmount();

    const completo = render(<EncabezadoPagina titulo="Usuarios" subtitulo="Gestiona cuentas"><button>Nuevo</button></EncabezadoPagina>);
    expect(completo.getByText('Gestiona cuentas')).toBeTruthy();
    expect(completo.getByText('Nuevo')).toBeTruthy();
  });
});
