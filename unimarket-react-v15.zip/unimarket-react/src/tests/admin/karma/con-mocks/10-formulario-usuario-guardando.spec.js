import { cleanup, fireEvent, render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import FormularioUsuario from '../../../../admin/components/FormularioUsuario';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Estado (state)', () => {
  afterEach(cleanup);

  it('K10) FormularioUsuario bloquea el boton mientras guarda y luego muestra el error devuelto', async () => {
    let terminar;
    const onGuardar = jasmine.createSpy('onGuardar').and.returnValue(new Promise((resolver) => { terminar = resolver; }));
    const { getByText, findByRole, container } = render(
      <MemoryRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <FormularioUsuario onGuardar={onGuardar} textoBoton="Crear usuario" />
      </MemoryRouter>
    );

    fireEvent.click(getByText('Crear usuario'));
    const boton = await new Promise((ok) => setTimeout(() => ok(container.querySelector('button[type="submit"]')), 0));
    expect(boton.disabled).toBe(true);
    expect(boton.textContent).toBe('Guardando...');

    terminar({ ok: false, mensaje: 'El correo ya está registrado.' });
    const alerta = await findByRole('alert');
    expect(alerta.textContent).toBe('El correo ya está registrado.');
    expect(container.querySelector('button[type="submit"]').disabled).toBe(false);
  });
});
