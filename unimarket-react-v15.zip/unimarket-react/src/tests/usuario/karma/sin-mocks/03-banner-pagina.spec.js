import { cleanup, render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import BannerPagina from '../../../../usuario/components/BannerPagina';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Propiedades (props)', () => {
  afterEach(cleanup);

  it('K3) BannerPagina muestra el titulo, el subtitulo y el enlace que recibe', () => {
    const { getByText, container } = render(
      <MemoryRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <BannerPagina titulo="Mis compras" subtitulo="Tus boletas" enlaceA="/perfil" enlaceTexto="Volver al perfil" />
      </MemoryRouter>
    );

    expect(getByText('Mis compras')).toBeTruthy();
    expect(getByText('Tus boletas')).toBeTruthy();
    const enlace = container.querySelector('a');
    expect(enlace.getAttribute('href')).toBe('/perfil');
    expect(enlace.textContent).toContain('Volver al perfil');
  });
});
