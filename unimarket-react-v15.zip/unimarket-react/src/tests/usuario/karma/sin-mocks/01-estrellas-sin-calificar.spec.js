import { cleanup, render } from '@testing-library/react';
import Estrellas from '../../../../usuario/components/Estrellas';

// Ajuste para Testing Library
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

describe('Renderizado correcto', () => {
  afterEach(cleanup);

  it('K1) Estrellas muestra "Sin calificar" sin votos y el promedio cuando existe', () => {
    const vacio = render(<Estrellas valor={0} cantidad={0} />);
    expect(vacio.getByText('Sin calificar')).toBeTruthy();
    expect(vacio.getByRole('img').getAttribute('aria-label')).toBe('Sin calificaciones');
    vacio.unmount();

    const conNota = render(<Estrellas valor={4.5} cantidad={2} />);
    expect(conNota.getByText('4.5')).toBeTruthy();
    expect(conNota.getByRole('img').getAttribute('aria-label')).toBe('4.5 de 5 estrellas');
  });
});
