# UniMarket (React)

Marketplace estudiantil migrado de HTML + JS puro a **React + Vite + React Router + Tailwind**.
Sigue sin backend: usuarios, artículos, carrito, sesión y fotos viven en `localStorage`.

## Cómo ejecutarlo

```bash
npm install
npm run dev      # servidor de desarrollo (http://localhost:5173)
npm run build    # build de producción en /dist
```

Cuenta de prueba: `juan.perez@unimarket.edu` / `123456`

## Equivalencias HTML -> React

| Antes | Ahora (ruta) | Archivo |
|---|---|---|
| `index.html` | `/` | `src/pages/Catalogo.jsx` |
| `login.html` | `/login` | `src/pages/Login.jsx` |
| `registro.html` | `/registro` | `src/pages/Registro.jsx` |
| `publicar.html` | `/publicar` | `src/pages/Publicar.jsx` |
| `panel-vendedor.html` | `/panel-vendedor` | `src/pages/PanelVendedor.jsx` |
| `bolsa.html` | `/bolsa` | `src/pages/Bolsa.jsx` |
| `pago.html` | `/pago` | `src/pages/Pago.jsx` |
| `pedidos.html` | `/pedidos` | `src/pages/Pedidos.jsx` |
| `perfil.html` | `/perfil` | `src/pages/Perfil.jsx` |

| Antes | Ahora |
|---|---|
| `js/datos.js` (funciones en `window`) | `src/data/datos.js` (módulo ES, se importa) |
| `js/interfaz.js` (clase `MenuPerfil`) | `src/components/MenuPerfil.jsx` |
| `js/publicar.js` (`SelectorModal`, `CargadorFotos`, `FormularioPublicacion`) | `SelectorModal.jsx` + estado dentro de `Publicar.jsx` |
| `js/catalogo.js` | estado + `useMemo` dentro de `Catalogo.jsx` |
| funciones repetidas en cada `<script>` (`escaparHtml`, `obtenerColorImagen`, `obtenerLineasDeBolsa`...) | `src/utils/utilidades.js` (una sola vez) |
| `haySesionActiva()` + redirección manual en cada página | `AuthContext` + `components/Rutas.jsx` |
| carrito leído/escrito en cada página | `CarritoContext` (el contador del header se actualiza solo) |
| header copiado en 3 páginas | `src/components/Header.jsx` |
| `css/*.css` | `src/styles/*.css` (sin cambios, salvo 2 clases renombradas) |

## Cambios a tener en cuenta

- **Tailwind** ya no va por CDN: se instala con npm (`tailwind.config.js` conserva los colores `primary`, `accent`, `surface`).
- **Font Awesome** sigue cargándose por CDN desde `index.html`.
- Como ahora todo el CSS convive en una sola app, se renombraron 2 clases que chocaban:
  `.form-hint` -> `.auth-hint` (solo login) y `.card` -> `.perfil-card` (solo perfil).
- Cada página agrega su clase al `<body>` (`auth-body`, `perfil-body`...) con el hook `useBodyClass`.
- `escaparHtml()` desapareció: React escapa el texto automáticamente.
- `USUARIO_ACTUAL` (usuario de ejemplo de respaldo) se eliminó: las rutas protegidas ya garantizan que hay sesión.
- Al guardar el perfil ya no se recarga la página: la sesión se actualiza y toda la app se refresca sola.
- Las contraseñas siguen en texto plano en `localStorage` (solo válido para demo).

## Selector de idioma

- Botón con bandera junto al ícono de perfil (`src/components/SelectorIdioma.jsx`), disponible en todas las páginas que usan `Header`.
- Idiomas: Español, English y Português. El elegido se guarda en `localStorage` (`unimarket_idioma`).
- Los textos viven en `src/i18n/traducciones.js`; se usan con `const { t } = useIdioma(); t('clave')`.
- Por ahora están traducidos el header, el menú de perfil y el catálogo (incluido el modal del producto). Para traducir otra página, agrega sus claves en los 3 idiomas y reemplaza los textos fijos por `t('clave')`.
- Las banderas son SVG en `public/img/flags/` (Windows no dibuja los emojis de banderas).
