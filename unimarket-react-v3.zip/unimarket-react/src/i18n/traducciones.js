// ============================================================
// Idiomas disponibles y sus textos.
//
// Para agregar un idioma nuevo:
//   1. Agrega una entrada en IDIOMAS (codigo, nombre y bandera).
//   2. Pon su bandera en public/img/flags/<codigo>.svg
//   3. Agrega su bloque de textos en TRADUCCIONES con las mismas claves.
//
// Para traducir un texto nuevo: agrega la clave en los tres bloques y
// usalo en el componente con  t('clave').
// ============================================================

export const IDIOMAS = [
  { codigo: 'es', nombre: 'Español', bandera: '/img/flags/es.svg' },
  { codigo: 'en', nombre: 'English', bandera: '/img/flags/en.svg' },
  { codigo: 'pt', nombre: 'Português', bandera: '/img/flags/pt.svg' },
];

export const IDIOMA_POR_DEFECTO = 'es';

export const TRADUCCIONES = {
  es: {
    // Header / menu de perfil
    'header.buscar': 'Buscar snacks, ropa, tecnología...',
    'header.idioma': 'Idioma',
    'menu.perfil': 'Ver mi perfil',
    'menu.pedidos': 'Mis pedidos',
    'menu.panel': 'Panel vendedor',
    'menu.salir': 'Salir de la sesión',
    'menu.usuario': 'Usuario',

    // Catalogo
    'catalogo.titulo': 'Encuentra lo que necesitas en tu campus',
    'catalogo.subtitulo': 'Compra y vende snacks, ropa, tecnología y más con estudiantes de tu universidad.',
    'catalogo.detectar': 'Detectar ubicación',
    'catalogo.ubicacionDetectada': 'Ubicación detectada',
    'catalogo.ubicacionSimulada': 'Ubicación simulada (CDMX)',
    'catalogo.radio': 'Radio:',
    'catalogo.menosDe': 'A menos de {radio} km de tu ubicación',
    'catalogo.menosDeSimulado': 'A menos de {radio} km (simulado)',
    'catalogo.ctaTitulo': '¿Quieres vender lo que ya no usas?',
    'catalogo.ctaTexto': 'Publica tus artículos y gana dinero extra en tu comunidad.',
    'catalogo.publicar': 'Publicar artículo',
    'catalogo.cerca': 'Artículos cerca de ti',
    'catalogo.vacio': 'No hay artículos que coincidan con tu búsqueda o filtros.',
    'catalogo.filtroUniversidad': 'Filtrar por Universidad',
    'catalogo.errorUbicacion': 'No se pudo obtener ubicación real. Usamos una ubicación simulada.',

    // Filtros de categoria
    'cat.todos': 'Todos',
    'cat.snacks': 'Snacks & Dulces',
    'cat.ropa': 'Ropa 2da Mano',
    'cat.tecnologia': 'Tecnología Usada',
    'cat.libros': 'Libros y Material',
    'cat.otros': 'Otros',

    // Modal de producto
    'modal.cerrar': 'Cerrar',
    'modal.sinCondicion': 'Sin condición',
    'modal.sinDescripcion': 'Sin descripción disponible.',
    'modal.precio': 'Precio',
    'modal.universidad': 'Universidad',
    'modal.distancia': 'Distancia',
    'modal.calificacion': 'Calificación',
    'modal.entrega': 'Punto de entrega',
    'modal.entregaAConvenir': 'A convenir con el vendedor',
    'modal.agregar': 'Agregar a la bolsa',
    'modal.agregado': 'Agregado a la bolsa',
  },

  en: {
    'header.buscar': 'Search snacks, clothes, tech...',
    'header.idioma': 'Language',
    'menu.perfil': 'View my profile',
    'menu.pedidos': 'My orders',
    'menu.panel': 'Seller dashboard',
    'menu.salir': 'Log out',
    'menu.usuario': 'User',

    'catalogo.titulo': 'Find what you need on your campus',
    'catalogo.subtitulo': 'Buy and sell snacks, clothes, tech and more with students from your university.',
    'catalogo.detectar': 'Detect location',
    'catalogo.ubicacionDetectada': 'Location detected',
    'catalogo.ubicacionSimulada': 'Simulated location (CDMX)',
    'catalogo.radio': 'Radius:',
    'catalogo.menosDe': 'Within {radio} km of your location',
    'catalogo.menosDeSimulado': 'Within {radio} km (simulated)',
    'catalogo.ctaTitulo': 'Want to sell what you no longer use?',
    'catalogo.ctaTexto': 'Post your items and earn extra money in your community.',
    'catalogo.publicar': 'Post an item',
    'catalogo.cerca': 'Items near you',
    'catalogo.vacio': 'No items match your search or filters.',
    'catalogo.filtroUniversidad': 'Filter by University',
    'catalogo.errorUbicacion': 'Could not get your real location. We used a simulated one.',

    'cat.todos': 'All',
    'cat.snacks': 'Snacks & Sweets',
    'cat.ropa': 'Second-hand Clothes',
    'cat.tecnologia': 'Used Tech',
    'cat.libros': 'Books & Supplies',
    'cat.otros': 'Other',

    'modal.cerrar': 'Close',
    'modal.sinCondicion': 'No condition',
    'modal.sinDescripcion': 'No description available.',
    'modal.precio': 'Price',
    'modal.universidad': 'University',
    'modal.distancia': 'Distance',
    'modal.calificacion': 'Rating',
    'modal.entrega': 'Pickup point',
    'modal.entregaAConvenir': 'To be agreed with the seller',
    'modal.agregar': 'Add to bag',
    'modal.agregado': 'Added to bag',
  },

  pt: {
    'header.buscar': 'Buscar lanches, roupas, tecnologia...',
    'header.idioma': 'Idioma',
    'menu.perfil': 'Ver meu perfil',
    'menu.pedidos': 'Meus pedidos',
    'menu.panel': 'Painel do vendedor',
    'menu.salir': 'Sair da conta',
    'menu.usuario': 'Usuário',

    'catalogo.titulo': 'Encontre o que você precisa no seu campus',
    'catalogo.subtitulo': 'Compre e venda lanches, roupas, tecnologia e mais com estudantes da sua universidade.',
    'catalogo.detectar': 'Detectar localização',
    'catalogo.ubicacionDetectada': 'Localização detectada',
    'catalogo.ubicacionSimulada': 'Localização simulada (CDMX)',
    'catalogo.radio': 'Raio:',
    'catalogo.menosDe': 'A menos de {radio} km da sua localização',
    'catalogo.menosDeSimulado': 'A menos de {radio} km (simulado)',
    'catalogo.ctaTitulo': 'Quer vender o que você não usa mais?',
    'catalogo.ctaTexto': 'Publique seus itens e ganhe uma renda extra na sua comunidade.',
    'catalogo.publicar': 'Publicar item',
    'catalogo.cerca': 'Itens perto de você',
    'catalogo.vacio': 'Nenhum item corresponde à sua busca ou filtros.',
    'catalogo.filtroUniversidad': 'Filtrar por Universidade',
    'catalogo.errorUbicacion': 'Não foi possível obter sua localização real. Usamos uma simulada.',

    'cat.todos': 'Todos',
    'cat.snacks': 'Lanches e Doces',
    'cat.ropa': 'Roupas de Segunda Mão',
    'cat.tecnologia': 'Tecnologia Usada',
    'cat.libros': 'Livros e Material',
    'cat.otros': 'Outros',

    'modal.cerrar': 'Fechar',
    'modal.sinCondicion': 'Sem condição',
    'modal.sinDescripcion': 'Sem descrição disponível.',
    'modal.precio': 'Preço',
    'modal.universidad': 'Universidade',
    'modal.distancia': 'Distância',
    'modal.calificacion': 'Avaliação',
    'modal.entrega': 'Ponto de entrega',
    'modal.entregaAConvenir': 'A combinar com o vendedor',
    'modal.agregado': 'Adicionado à sacola',
    'modal.agregar': 'Adicionar à sacola',
  },
};
