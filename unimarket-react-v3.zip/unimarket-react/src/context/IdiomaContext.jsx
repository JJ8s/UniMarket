import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { IDIOMAS, IDIOMA_POR_DEFECTO, TRADUCCIONES } from '../i18n/traducciones';

const CLAVE_IDIOMA = 'unimarket_idioma';
const IdiomaContext = createContext(null);

function leerIdiomaGuardado() {
  try {
    const guardado = localStorage.getItem(CLAVE_IDIOMA);
    if (IDIOMAS.some((i) => i.codigo === guardado)) return guardado;
  } catch {
    /* localStorage no disponible: se usa el idioma por defecto */
  }
  return IDIOMA_POR_DEFECTO;
}

/**
 * Idioma activo de toda la app. Expone:
 *   idioma / setIdioma(codigo)  -> idioma actual y cambiarlo (se recuerda)
 *   t('clave', { var: valor })  -> texto traducido; si falta, cae a español
 */
export function IdiomaProvider({ children }) {
  const [idioma, setIdiomaEstado] = useState(leerIdiomaGuardado);

  // Mantiene <html lang="..."> al dia (accesibilidad / traductores del navegador)
  useEffect(() => {
    document.documentElement.lang = idioma;
  }, [idioma]);

  const setIdioma = useCallback((codigo) => {
    setIdiomaEstado(codigo);
    try {
      localStorage.setItem(CLAVE_IDIOMA, codigo);
    } catch {
      /* ignorar */
    }
  }, []);

  const t = useCallback(
    (clave, variables = {}) => {
      const texto = TRADUCCIONES[idioma]?.[clave] ?? TRADUCCIONES[IDIOMA_POR_DEFECTO][clave] ?? clave;
      return Object.entries(variables).reduce(
        (resultado, [nombre, valor]) => resultado.replace(`{${nombre}}`, valor),
        texto
      );
    },
    [idioma]
  );

  const valor = useMemo(() => ({ idioma, setIdioma, t }), [idioma, setIdioma, t]);
  return <IdiomaContext.Provider value={valor}>{children}</IdiomaContext.Provider>;
}

export function useIdioma() {
  return useContext(IdiomaContext);
}
