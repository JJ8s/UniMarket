import { useEffect, useRef, useState } from 'react';
import { IDIOMAS } from '../i18n/traducciones';
import { useIdioma } from '../context/IdiomaContext';

/**
 * Boton con la bandera del idioma actual + menu para elegir otro.
 * Se cierra al elegir, al hacer click afuera o con Escape.
 */
export default function SelectorIdioma() {
  const { idioma, setIdioma, t } = useIdioma();
  const [abierto, setAbierto] = useState(false);
  const contenedorRef = useRef(null);
  const actual = IDIOMAS.find((i) => i.codigo === idioma) || IDIOMAS[0];

  useEffect(() => {
    if (!abierto) return undefined;
    const alHacerClick = (evento) => {
      if (contenedorRef.current && !contenedorRef.current.contains(evento.target)) setAbierto(false);
    };
    const alPresionarTecla = (evento) => {
      if (evento.key === 'Escape') setAbierto(false);
    };
    document.addEventListener('click', alHacerClick);
    document.addEventListener('keydown', alPresionarTecla);
    return () => {
      document.removeEventListener('click', alHacerClick);
      document.removeEventListener('keydown', alPresionarTecla);
    };
  }, [abierto]);

  const elegir = (codigo) => {
    setIdioma(codigo);
    setAbierto(false);
  };

  return (
    <div className="relative" ref={contenedorRef}>
      <button
        type="button"
        className="idioma-btn"
        aria-label={`${t('header.idioma')}: ${actual.nombre}`}
        aria-haspopup="listbox"
        aria-expanded={abierto}
        onClick={() => setAbierto((valor) => !valor)}
      >
        <img src={actual.bandera} alt="" className="idioma-bandera" />
        <svg xmlns="http://www.w3.org/2000/svg" className="idioma-flecha" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 0 1 1.06.02L10 11.17l3.71-3.94a.75.75 0 1 1 1.08 1.04l-4.25 4.5a.75.75 0 0 1-1.08 0l-4.25-4.5a.75.75 0 0 1 .02-1.06Z" clipRule="evenodd" />
        </svg>
      </button>

      {abierto && (
        <ul className="idioma-menu" role="listbox">
          {IDIOMAS.map((opcion) => (
            <li key={opcion.codigo} role="option" aria-selected={opcion.codigo === idioma}>
              <button
                type="button"
                className={`idioma-opcion ${opcion.codigo === idioma ? 'activo' : ''}`}
                onClick={() => elegir(opcion.codigo)}
              >
                <img src={opcion.bandera} alt="" className="idioma-bandera" />
                <span>{opcion.nombre}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
