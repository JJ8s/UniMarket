import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

/** Solo con sesion activa; si no, al login. */
export function RutaProtegida() {
  const { usuario } = useAuth();
  return usuario ? <Outlet /> : <Navigate to="/login" replace />;
}

/** Login y registro: si ya hay sesion, al catalogo. */
export function RutaPublica() {
  const { usuario } = useAuth();
  return usuario ? <Navigate to="/" replace /> : <Outlet />;
}
