import { Navigate, Route, Routes } from 'react-router-dom';
import { RutaProtegida, RutaPublica } from './components/Rutas';
import Catalogo from './pages/Catalogo';
import Login from './pages/Login';
import Registro from './pages/Registro';
import Publicar from './pages/Publicar';
import PanelVendedor from './pages/PanelVendedor';
import Bolsa from './pages/Bolsa';
import Pago from './pages/Pago';
import Pedidos from './pages/Pedidos';
import Perfil from './pages/Perfil';

export default function App() {
  return (
    <Routes>
      <Route element={<RutaPublica />}>
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />
      </Route>

      <Route element={<RutaProtegida />}>
        <Route path="/" element={<Catalogo />} />
        <Route path="/publicar" element={<Publicar />} />
        <Route path="/panel-vendedor" element={<PanelVendedor />} />
        <Route path="/bolsa" element={<Bolsa />} />
        <Route path="/pago" element={<Pago />} />
        <Route path="/pedidos" element={<Pedidos />} />
        <Route path="/perfil" element={<Perfil />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
