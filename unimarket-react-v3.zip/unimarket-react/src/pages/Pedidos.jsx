import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import useBodyClass from '../hooks/useBodyClass';
import useMisArticulos from '../hooks/useMisArticulos';
import { formatearFecha } from '../utils/utilidades';

export default function Pedidos() {
  useBodyClass('perfil-body');
  const { usuario } = useAuth();
  const { misArticulos, borrarArticulo } = useMisArticulos(usuario.nombre);

  return (
    <>
      <div className="perfil-header-logo">
        <Link to="/"><img src="/img/logo.png" alt="UniMarket" /></Link>
      </div>

      <main className="orders-wrapper">
        <header className="banner-card">
          <div>
            <h1 style={{ fontSize: '1.6rem', fontWeight: 700 }}>Mis Pedidos</h1>
            <p style={{ color: '#93c5fd', fontSize: '0.95rem', marginTop: '0.2rem' }}>Publicaciones que has creado en UniMarket</p>
          </div>
          <Link to="/perfil" className="btn-ghost-on-dark">
            <i className="fa-solid fa-arrow-left"></i> Volver al perfil
          </Link>
        </header>

        <div>
          {misArticulos.map((articulo) => (
            <section className="publicacion-card" key={articulo.id}>
              <div className="publicacion-header">
                <span className="order-id">{articulo.sku || 'Sin SKU'}</span>
                <span className="order-date">Publicado el {formatearFecha(articulo.creadoEn)}</span>
              </div>
              <div className="publicacion-body">
                <div className="order-details">
                  <h3>{articulo.nombre}</h3>
                  <p className="publicacion-meta">
                    {articulo.condicion || 'Sin condición'} · Stock: {articulo.stock ?? 0} · Punto de entrega: {articulo.entrega || 'A convenir'}
                  </p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                  <p className="publicacion-precio">${Number(articulo.precio).toFixed(2)}</p>
                  <button
                    className="btn-delete-outline"
                    onClick={() =>
                      borrarArticulo(articulo.id, '¿Seguro que quieres borrar esta publicación? Esta acción no se puede deshacer.')
                    }
                  >
                    <i className="fa-solid fa-trash"></i> Borrar
                  </button>
                </div>
              </div>
            </section>
          ))}
        </div>

        {misArticulos.length === 0 && (
          <div className="empty-state">
            <p style={{ marginBottom: '1rem' }}>Todavía no has publicado ningún artículo.</p>
            <Link to="/publicar" className="btn-primary-orange" style={{ display: 'inline-flex', maxWidth: '260px', margin: '0 auto' }}>
              <i className="fa-solid fa-plus"></i> Publicar mi primer artículo
            </Link>
          </div>
        )}
      </main>
    </>
  );
}
